import pandas as pd
from flask import Flask, request, render_template
import joblib


#Create an object of Flask class
app = Flask(__name__)

#Load the trained model (Pickle file)
model = joblib.load('../lr_model.pkl')

#use the Flask's app.route() decorator to map the URL '/' to trigger home() function
@app.route('/')
def home():
    return render_template('index.html')


#use the Flask's app.route() decorator to map the URL '/predict' to trigger predict() function.
@app.route('/predict',methods=['POST'])
def predict():
    tv, radio, newspaper = [float(x) for x in request.form.values()]     
    # Format the input data to a dataframe
    new_data = pd.DataFrame({'TV':tv,'radio':radio,'newspaper':newspaper, }, index=[0])  
    # use dataframe to predict result by passing it to the predict() method
    result = model.predict(new_data)
    # return index.html file with prediction text
    return render_template('index.html', prediction_text='Predicted Sales of items (in thousands) is {}'.format(result))

if __name__ == "__main__":
    app.run(debug=True)