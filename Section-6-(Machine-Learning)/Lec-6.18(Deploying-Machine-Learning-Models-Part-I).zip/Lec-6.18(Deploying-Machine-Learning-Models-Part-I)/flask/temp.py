from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Hello Flask with Arif......</h1>'
    #return render_template('hello_flask.html')

if __name__ == '__main__':
    app.run(debug=True)