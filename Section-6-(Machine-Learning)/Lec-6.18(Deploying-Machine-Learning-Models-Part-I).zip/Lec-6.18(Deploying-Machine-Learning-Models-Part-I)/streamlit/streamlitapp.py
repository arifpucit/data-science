import pandas as pd
import joblib

import streamlit as st

# Load the Model 
model = joblib.load('../lr_model.pkl')

# UI Elements, to get input
st.title('Advertising Budget Prediction')
tv = st.number_input('TV', step=1)
radio = st.number_input('Radio', step=1)
newspaper = st.number_input('Newspaper', step=1)
    
# Format the input data to a dataframe
new_data = pd.DataFrame({'TV':tv,'radio':radio,'newspaper':newspaper, }, index=[0])
    

result=""
if st.button("Predict"):
    result = model.predict(new_data)
    st.subheader("Predicted Sale of Items (in thousand units)")
    st.subheader(result)
else:
    st.subheader("Enter ad budget and click Predict button")