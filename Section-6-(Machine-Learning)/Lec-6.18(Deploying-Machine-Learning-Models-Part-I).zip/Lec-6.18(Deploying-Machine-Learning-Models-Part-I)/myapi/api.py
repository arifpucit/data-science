from flask import Flask, request, jsonify
import joblib
import pandas as pd

# Create Flask App
app = Flask(__name__)

# Load the saved model
model = joblib.load("../lr_model.pkl") 

# Create API routing call
@app.route('/predict', methods=['POST'])
def predict():
    # Get JSON Request
    new_data = request.json
    # Convert JSON request to Pandas DataFrame
    df = pd.DataFrame(new_data)
    # Get prediction
    prediction = model.predict(df)
    # Return JSON version of Prediction
    return jsonify({'prediction': float(prediction)})

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0', port=12345)